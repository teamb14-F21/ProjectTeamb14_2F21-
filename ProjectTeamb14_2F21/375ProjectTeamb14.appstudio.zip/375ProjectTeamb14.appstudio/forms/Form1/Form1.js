
Form1.onshow=function(){
  //Label1.value = weather.current.temp_f
  console.log("in Form1" + weather.current.temp_f)
}
