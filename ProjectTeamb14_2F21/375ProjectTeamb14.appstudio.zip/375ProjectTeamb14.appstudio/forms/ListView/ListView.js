

sldrInterest = [] 

/*
ListView.onshow=function(){
  lblSaved.className = ""
  lblSaved.style.color = "#FFFFFF"
  lblListView.className = ""
  lblListView.style.color = "#FFFFFF"
  lblMapView.className = ""
  lblMapView.style.color = "#FFFFFF"
  lblWeather.className = ""
  lblWeather.style.color = "#FFFFFF"
  slctFilters.className = ""
  slctFilters.style.color = "#000000"
  lblBusName.className = ""
  lblBusName.style.color = "#000000"
  lblBusName1.className = ""
  lblBusName1.style.color = "#000000"
  lblBusName2.className = ""
  lblBusName2.style.color = "#000000"
  lblLocation1.className = ""
  lblLocation1.style.color = "#000000"
  lblLocation2.className = ""
  lblLocation2.style.color = "#000000"
  lblLocation3.className = ""
  lblLocation3.style.color = "#000000"
  lblHours.className = ""
  lblHours.style.color = "#000000"
  lblHours1.className = ""
  lblHours1.style.color = "#000000"
  lblHours2.className = ""
  lblHours2.style.color = "#000000"
  lblRating.className = ""
  lblRating.style.color = "#FF0000"
  lblRating1.className = ""
  lblRating1.style.color = "#FF0000"
  lblRating2.className = ""
  lblRating2.style.color = "#FF0000"
  lblInterestLevel.className = ""
  lblInterestLevel.style.color = "#000000"
  lblInterestLevel1.className = ""
  lblInterestLevel1.style.color = "#000000"
  lblInterestLevel2.className = ""
  lblInterestLevel2.style.color = "#000000"

}
*/
imgWeather.onclick=function(){
  ChangeForm(Weather)
}
lblWeather.onclick=function(){
  ChangeForm(Weather)
}

imgListView.onclick=function(){
  ChangeForm(ListView)
}

lblListView.onclick=function(){
    ChangeForm(ListView)
}

imgSaved.onclick=function(){
  ChangeForm(Saved)
}

lblSaved.onclick=function(){
  ChangeForm(Saved)
}

imgMap.onclick=function(){
  ChangeForm(MapView)
}

lblMapView.onclick=function(){
  ChangeForm(MapView)
}

sldrInterest.ontouchend=function(){
    ChangeForm(Saved)
}


let yelper

const extraHeaders = {
    method: 'get',
    headers: new Headers({
        "accept": "application/json",
        'Authorization': "Bearer RzQPCrzmAgbYjUmeXMFQn2SzRGOWSzTUmHB6MfuX_ZYDBnqiUNrcw_VVIO_WjFpEWZ9vYlJ8mxo1Yj0bknYj7-zz--yk1Vb-5t9oENOnXlcesoA1OKXjeJk4YBSlYXYx"
        //'Access-Control-Allow-Origin': '*'
        ,'Access-Control-Request-Method':'GET'
    })
}

  let locations = "Omaha"
  let term = "restaurant"
  let price = 2
  
  // before running, go to https://cors-anywhere.herokuapp.com/ and 
  // click on requesting temporary permission - only does up to 50/hr. 
 // let URL = 'https://cors-anywhere.herokuapp.com/https://api.yelp.com/v3/businesses/search?location=' + locations + '&term=' + term + '&price=' + price
 //const URL = 'https://cors.bridged.cc/https://api.yelp.com/v3/businesses/search?location=' + locations + '&term=' + term + '&price=' + price

let URL = 'https://api.yelp.com/v3/businesses/search?location=' + locations + '&term=' + term + '&price=' + price
function getYelp() {
  fetch(URL,extraHeaders)
    .then(function(response) {  
        return response.json()
    })
    .then(function(data) {
        console.log(`in second then with data ${data.businesses[0].name}`)
        freeData(data)
    })
    .catch(function() {
        // catch errors
    })
}

function freeData(apiData) {
    yelper = apiData
}

ListView.onshow=function(){
 getYelp()
 lblBusName.value = yelper.business[0].name
}


