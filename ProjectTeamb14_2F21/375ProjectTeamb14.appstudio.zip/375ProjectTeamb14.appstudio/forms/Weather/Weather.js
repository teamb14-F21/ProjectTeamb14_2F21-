



Weather.onshow=function(){
  lblSaved1.className = ""
  lblSaved1.style.color = "#FFFFFF"
  lblListView1.className = ""
  lblListView1.style.color = "#FFFFFF"
  lblMapView1.className = ""
  lblMapView1.style.color = "#FFFFFF"
  lblWeather1.className = ""
  lblWeather1.style.color = "#FFFFFF"
  lblDate1.className = ""
  lblDate1.style.color = "#000000"
  lblDate2.className = ""
  lblDate2.style.color = "#000000"
  lblDate3.className = ""
  lblDate3.style.color = "#000000"
  lblDate4.className = ""
  lblDate4.style.color = "#000000"
  lblDate5.className = ""
  lblDate5.style.color = "#000000"
  lblCondition.className = ""
  lblCondition.style.color = "#000000"
  lblCondition1.className = ""
  lblCondition1.style.color = "#000000"
  lblCondition2.className = ""
  lblCondition2.style.color = "#000000"
  lblCondition3.className = ""
  lblCondition3.style.color = "#000000"
  lblCondition4.className = ""
  lblCondition4.style.color = "#000000"
  lblTemp.className = ""
  lblTemp.style.color = "#000000"
  lblTemp1.className = ""
  lblTemp1.style.color = "#000000"
  lblTemp2.className = ""
  lblTemp2.style.color = "#000000"
  lblTemp3.className = ""
  lblTemp3.style.color = "#000000"
  lblTemp4.className = ""
  lblTemp4.style.color = "#000000"
}

imgWeather1.onclick=function(){
  ChangeForm(Weather)
}
lblWeather1.onclick=function(){
  ChangeForm(Weather)
}

imgListView1.onclick=function(){
  ChangeForm(ListView)
}

lblListView1.onclick=function(){
    ChangeForm(ListView)
}

imgSaved1.onclick=function(){
  ChangeForm(Saved)
}

lblSaved1.onclick=function(){
  ChangeForm(Saved)
}

imgMap1.onclick=function(){
  ChangeForm(MapView)
}

lblMapView1.onclick=function(){
  ChangeForm(MapView)
}


let weather = ""
const URL = "http://api.weatherapi.com/v1/forecast.json?Key=ac52bdb5ac1a416cb87215350211711&q=68131"

// API call that returns api data
const getData = () => 
       fetch(URL).then(response => response.json()).then(({results}) => results)

// create a function to put the api data into the projects' global variable 'weather'
 function freeData(apiData) {
     weather = apiData  
}
    
//  ***Main Program *** //





Weather.onshow=function(){
// call the API call function getData() to start the process
getData().then(data => {
    freeData(data)           // when getData() is done, call freeData with the api data that was returned
    console.log(data)
    weather = data
})
ChangeForm(Form1)
 // Label1.value = `The current weather is ${weather.location.name}`
}

