/*
API source: https://openweathermap.org/appid
Good examples: https://bithacker.dev/fetch-weather-openweathermap-api-javascript
This project has a couple of console.logs just for debugging - they 
can be commented out. 
*/

// Cindy Nov 2021 api key: c515880619500d7f6d1e3731af1c40a7

// city variable will default to Omaha if user doesn't type a city
// let city = "Omaha"

function getWeather() {
  let Key = 'ac52bdb5ac1a416cb87215350211711'
  fetch('http://api.weatherapi.com/v1/forecast.json?Key=ac52bdb5ac1a416cb87215350211711&q=68131')  
  .then(function(resp) { return resp.json() }) // Convert data to json
  .then(function(data) {
      freeData(data) 
    })
  .catch(function() {
    // catch any errors
  })
}

// line 9   .then(function(data) {console.log(data) })


function freeData(apiData) {
    // just getting temp for proof of concept
    console.log(`in freeData,${apiData}`)
    // put api data into global variable so can use in other forms
    weather = apiData  
}

btnCallTheAPI.onclick=function(){    
    getWeather()
}


btnSeeData.onclick=function(){
  ChangeForm(Form1)
}

