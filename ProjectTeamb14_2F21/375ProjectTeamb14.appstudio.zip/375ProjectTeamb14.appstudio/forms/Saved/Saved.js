






imgWeather2.onclick=function(){
  ChangeForm(Weather)
}
lblWeather2.onclick=function(){
  ChangeForm(Weather)
}

imgListView2.onclick=function(){
  ChangeForm(ListView)
}

lblListView2.onclick=function(){
    ChangeForm(ListView)
}

imgSaved2.onclick=function(){
  ChangeForm(Saved)
}

lblSaved2.onclick=function(){
  ChangeForm(Saved)
}

imgMap2.onclick=function(){
  ChangeForm(MapView)
}

lblMapView2.onclick=function(){
  ChangeForm(MapView)
}
