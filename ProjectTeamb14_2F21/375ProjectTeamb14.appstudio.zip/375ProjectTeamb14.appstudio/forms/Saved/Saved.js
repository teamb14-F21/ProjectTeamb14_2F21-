




Saved.onshow=function(){
  lblSaved2.className = ""
  lblSaved2.style.color = "#FFFFFF"
  lblListView2.className = ""
  lblListView2.style.color = "#FFFFFF"
  lblMapView2.className = ""
  lblMapView2.style.color = "#FFFFFF"
  lblWeather2.className = ""
  lblWeather2.style.color = "#FFFFFF"
  slctFilters1.className = ""
  slctFilters1.style.color = "#000000"
  lblBusName.className = ""
  lblBusName.style.color = "#000000"
  lblBusName1.className = ""
  lblBusName1.style.color = "#000000"
  lblBusName2.className = ""
  lblBusName2.style.color = "#000000"
  lblLocation1.className = ""
  lblLocation1.style.color = "#000000"
  lblLocation2.className = ""
  lblLocation2.style.color = "#000000"
  lblLocation3.className = ""
  lblLocation3.style.color = "#000000"
  lblHours.className = ""
  lblHours.style.color = "#000000"
  lblHours1.className = ""
  lblHours1.style.color = "#000000"
  lblHours2.className = ""
  lblHours2.style.color = "#000000"
  lblRating.className = ""
  lblRating.style.color = "#FF0000"
  lblRating1.className = ""
  lblRating1.style.color = "#FF0000"
  lblRating2.className = ""
  lblRating2.style.color = "#FF0000"
  lblInterestLevel.className = ""
  lblInterestLevel.style.color = "#000000"
  lblInterestLevel1.className = ""
  lblInterestLevel1.style.color = "#000000"
  lblInterestLevel2.className = ""
  lblInterestLevel2.style.color = "#000000"
  
}

imgWeather2.onclick=function(){
  ChangeForm(Weather)
}
lblWeather2.onclick=function(){
  ChangeForm(Weather)
}

imgListView2.onclick=function(){
  ChangeForm(ListView)
}

lblListView2.onclick=function(){
    ChangeForm(ListView)
}

imgSaved2.onclick=function(){
  ChangeForm(Saved)
}

lblSaved2.onclick=function(){
  ChangeForm(Saved)
}

imgMap2.onclick=function(){
  ChangeForm(MapView)
}

lblMapView2.onclick=function(){
  ChangeForm(MapView)
}
